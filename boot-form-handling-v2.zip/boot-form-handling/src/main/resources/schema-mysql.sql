


CREATE TABLE IF NOT EXISTS book (
  bookId VARCHAR(10) NOT NULL,
  bookCategory VARCHAR(50),
  bookName VARCHAR(100) NOT NULL,
  bookAuthor VARCHAR(100) NOT NULL,
  bookEdition INTEGER,
  bookPrice DOUBLE
);