package com.javainuse.service;

import java.util.List;

import com.javainuse.model.Book;

public interface BookService {
	void insertBook(Book book);
	void insertBooks(List<Book> books);
	List<Book> getAllBooks();
	Book getBookById(String bookId);
	void deleteBook(String bookId);
	void updateId(Book book);
	void updateCategory(Book book);
	void updateName(Book book);
	void updateAuthor(Book book);
	void updateEdition(Book book);
	void updatePrice(Book book);
}