package com.javainuse.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javainuse.dao.BookDao;
import com.javainuse.model.Book;
import com.javainuse.service.BookService;

@Service
public class BookServiceImpl implements BookService {

	@Autowired
	BookDao bookDao;

	@Override
	public void insertBook(Book book) {
		bookDao.insertBook(book);
	}

	@Override
	public void insertBooks(List<Book> books) {
		bookDao.insertBooks(books);
	}

	public List<Book> getAllBooks() {
		return bookDao.getAllBooks();
	}

	@Override
	public Book getBookById(String bookId) {
		Book book=bookDao.getBookById(bookId);
		//System.out.println(book);
		return book;
	}
	
	@Override
	public void deleteBook(String bookId) {
		bookDao.deleteBook(bookId);
		
	}
	//update functions
	@Override
	public void updateId(Book book) {
		bookDao.updateId(book);
		
	}
	
	@Override
	public void updateCategory(Book book) {
		bookDao.updateCategory( book);
		
	}
	
	@Override
	public void updateName(Book book) {
		bookDao.updateName(book);
		
	}
	@Override
	public void updateAuthor(Book book) {
		bookDao.updateAuthor( book);
		
	}
	@Override
	public void updateEdition(Book book) {
		bookDao.updateEdition( book);
		
	}
	
	@Override
	public void updatePrice(Book book) {
		bookDao.updatePrice( book);
		
	}

}