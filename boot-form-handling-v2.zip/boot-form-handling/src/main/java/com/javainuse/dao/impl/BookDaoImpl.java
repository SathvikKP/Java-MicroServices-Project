package com.javainuse.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.javainuse.dao.BookDao;
import com.javainuse.model.Book;

@Repository
public class BookDaoImpl extends JdbcDaoSupport implements BookDao{
	
	@Autowired 
	DataSource dataSource;
	
	@PostConstruct
	private void initialize(){
		setDataSource(dataSource);
	}
	
	@Override
	public void insertBook(Book book) {
		String sql = "INSERT INTO book " +
				"(bookId, bookCategory, bookName, bookAuthor, bookEdition, bookPrice) VALUES (?, ?, ?, ?, ?, ?)" ;
		getJdbcTemplate().update(sql, new Object[]{
				book.getBookId(),book.getBookCategory(), book.getBookName(), book.getBookAuthor(), book.getBookEdition(), book.getBookPrice()
		});
	}
	
	@Override
	public void insertBooks(final List<Book> books) {
		String sql = "INSERT INTO book " + "(bookId, bookCategory, bookName, bookAuthor, bookEdition, bookPrice) VALUES (?, ?, ?, ?, ?, ?)";
		getJdbcTemplate().batchUpdate(sql, new BatchPreparedStatementSetter() {
			public void setValues(PreparedStatement ps, int i) throws SQLException {
				Book book = books.get(i);
				ps.setString(1, book.getBookId());
				ps.setString(2, book.getBookCategory());
				ps.setString(3, book.getBookName());
				ps.setString(4, book.getBookAuthor());
				ps.setInt(5, book.getBookEdition());
				ps.setDouble(6, book.getBookPrice());
			}
			
			public int getBatchSize() {
				return books.size();
			}
		});

	}
	@Override
	public List<Book> getAllBooks(){
		String sql = "SELECT * FROM book";
		List<Map<String, Object>> rows = getJdbcTemplate().queryForList(sql);
		
		List<Book> result = new ArrayList<Book>();
		for(Map<String, Object> row:rows){
			Book book = new Book();
			book.setBookId((String)row.get("bookId"));
			book.setBookCategory((String)row.get("bookCategory"));
			book.setBookName((String)row.get("bookName"));
			book.setBookAuthor((String)row.get("bookAuthor"));
			book.setBookEdition((Integer)row.get("bookEdition"));
			book.setBookPrice((Double)row.get("bookPrice"));
			result.add(book);
		}
		
		return result;
	}

	@Override
	public Book getBookById(String bookId) {
		String sql = "SELECT * FROM book WHERE bookId = ?";;
		return (Book)getJdbcTemplate().queryForObject(sql, new Object[]{bookId}, new RowMapper<Book>(){
			@Override
			public Book mapRow(ResultSet rs, int rwNumber) throws SQLException {
				Book book = new Book();
				book.setBookId(rs.getString("bookId"));
				book.setBookCategory(rs.getString("bookCategory"));
				book.setBookName(rs.getString("bookName"));
				book.setBookAuthor(rs.getString("bookAuthor"));
				book.setBookEdition(rs.getInt("bookEdition"));
				book.setBookPrice(rs.getDouble("bookPrice"));
				
				return book;
			}
		});
		
	}
	
	
	//Delete Method
	@Override
	public void deleteBook(String bookId) {
		String sql = "DELETE FROM book WHERE bookId = ?";;
		getJdbcTemplate().update(sql, new Object[]{bookId});
		
	}
	//Update Methods
		@Override
		public void updateId(Book book) {
			String sql = "UPDATE book SET bookId = ? WHERE bookName = ? and bookEdition= ?";;
			getJdbcTemplate().update(sql, new Object[]{book.getBookId(),book.getBookName(),book.getBookEdition()});
			
		}
		
		@Override
		public void updateCategory(Book book) {
			String sql = "UPDATE book SET bookCategory = ? WHERE bookId = ?";;
			getJdbcTemplate().update(sql, new Object[]{book.getBookCategory(),book.getBookId()});
			
		}
		
		@Override
		public void updateName(Book book) {
			String sql = "UPDATE book SET bookName = ? WHERE bookId = ?";;
			getJdbcTemplate().update(sql, new Object[]{book.getBookName(),book.getBookId()});
			
		}
		
		@Override
		public void updateAuthor(Book book) {
			String sql = "UPDATE book SET bookAuthor = ? WHERE bookId = ?";;
			getJdbcTemplate().update(sql, new Object[]{book.getBookAuthor(),book.getBookId()});
			
		}
		
		@Override
		public void updateEdition(Book book) {
			String sql = "UPDATE book SET bookEdition = ? WHERE bookId = ?";;
			getJdbcTemplate().update(sql, new Object[]{book.getBookEdition(),book.getBookId()});
			
		}
		
		@Override
		public void updatePrice(Book book) {
			String sql = "UPDATE book SET bookPrice = ? WHERE bookId = ?";;
			getJdbcTemplate().update(sql, new Object[]{book.getBookPrice(),book.getBookId()});
			
		}
}