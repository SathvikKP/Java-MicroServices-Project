package com.javainuse.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.javainuse.model.Book;
import com.javainuse.service.BookService;

@Controller
public class BookController {

	@Autowired
	BookService bookService;

	@RequestMapping("/welcome")
	public ModelAndView firstPage() {
		return new ModelAndView("welcome");
	}

	@RequestMapping(value = "/addNewBook", method = RequestMethod.GET)
	public ModelAndView show() {
		return new ModelAndView("addBook", "book", new Book());
	}

	@RequestMapping(value = "/addNewBook", method = RequestMethod.POST)
	public ModelAndView processRequest(@ModelAttribute("book") Book book) {
		
		bookService.insertBook(book);
		List<Book> books = bookService.getAllBooks();
		ModelAndView model = new ModelAndView("zbookadded");//getBooks->welcome
		model.addObject("books", books);
		return model;
	}

	@RequestMapping("/getBooks")
	public ModelAndView getBooks() {
		List<Book> books = bookService.getAllBooks();
		ModelAndView model = new ModelAndView("getBooks");
		model.addObject("books", books);
		return model;
	}
	
	//new codes
	
	@RequestMapping(value = "/getSpecificBook", method = RequestMethod.GET)
	public ModelAndView show1() {
		return new ModelAndView("zgetSpecificBook", "book", new Book());
	}
	
	
	@RequestMapping(value="/getSpecificBook", method = RequestMethod.POST)
	public ModelAndView getSpecificBook(@ModelAttribute("book") Book book) {
		Book book1 = bookService.getBookById(book.getBookId());
		ModelAndView model = new ModelAndView("zgetSpecificBookDisplay");
		model.addObject("book",book1);
		return model;
	}
	//Delete Route
	@RequestMapping(value = "/deleteBook", method = RequestMethod.GET)
	public ModelAndView show2() {
		return new ModelAndView("deleteBook", "book", new Book());
	}
	@RequestMapping(value = "/deleteBook", method = RequestMethod.POST)
	public ModelAndView deleteBook(@ModelAttribute("book") Book book) {
		
		bookService.deleteBook(book.getBookId());
		ModelAndView model = new ModelAndView("bookDeleted");
		model.addObject("book", book);
		return model;
	}
	
	//General Update Route
			@RequestMapping(value = "/updateBook", method = RequestMethod.GET)
			public ModelAndView show3() {
				return new ModelAndView("updateBook", "book", new Book());
			}
	//Update Id Route
		@RequestMapping(value = "/updateId", method = RequestMethod.GET)
		public ModelAndView show4() {
			return new ModelAndView("updateId", "book", new Book());
		}
		
		@RequestMapping(value = "/updateId", method = RequestMethod.POST)
		public ModelAndView updateBook(@ModelAttribute("book") Book book) {
			
			bookService.updateId(book);
			ModelAndView model = new ModelAndView("bookUpdated");
			model.addObject("book", book);
			return model;
		}
	//Update Category Route
		@RequestMapping(value = "/updateCategory", method = RequestMethod.GET)
		public ModelAndView show5() {
			return new ModelAndView("updateCategory", "book", new Book());
		}
		
		@RequestMapping(value = "/updateCategory", method = RequestMethod.POST)
		public ModelAndView updateCategory(@ModelAttribute("book") Book book) {
			
			bookService.updateCategory(book);
			ModelAndView model = new ModelAndView("bookUpdated");
			model.addObject("book", book);
			return model;
		}
	//Update Name Route
		@RequestMapping(value = "/updateName", method = RequestMethod.GET)
		public ModelAndView show6() {
			return new ModelAndView("updateName", "book", new Book());
		}
		@RequestMapping(value = "/updateName", method = RequestMethod.POST)
		public ModelAndView updateName(@ModelAttribute("book") Book book) {
			
			bookService.updateName(book);
			ModelAndView model = new ModelAndView("bookUpdated");
			model.addObject("book", book);
			return model;
		}
	//Update Author Route
		@RequestMapping(value = "/updateAuthor", method = RequestMethod.GET)
		public ModelAndView show7() {
			return new ModelAndView("updateAuthor", "book", new Book());
		}
		@RequestMapping(value = "/updateAuthor", method = RequestMethod.POST)
		public ModelAndView updateAuthor(@ModelAttribute("book") Book book) {
			
			bookService.updateAuthor(book);
			ModelAndView model = new ModelAndView("bookUpdated");
			model.addObject("book", book);
			return model;
		}
	//Update Edition Route
		@RequestMapping(value = "/updateEdition", method = RequestMethod.GET)
		public ModelAndView show8() {
			return new ModelAndView("updateEdition", "book", new Book());
		}
		@RequestMapping(value = "/updateEdition", method = RequestMethod.POST)
		public ModelAndView updateEdition(@ModelAttribute("book") Book book) {
			
			bookService.updateEdition(book);
			ModelAndView model = new ModelAndView("bookUpdated");
			model.addObject("book", book);
			return model;
		}
	//Update Price Route
		@RequestMapping(value = "/updatePrice", method = RequestMethod.GET)
		public ModelAndView show9() {
			return new ModelAndView("updatePrice", "book", new Book());
		}
		@RequestMapping(value = "/updatePrice", method = RequestMethod.POST)
		public ModelAndView updatePrice(@ModelAttribute("book") Book book) {
			
			bookService.updatePrice(book);
			ModelAndView model = new ModelAndView("bookUpdated");
			model.addObject("book", book);
			return model;
		}

		@RequestMapping(value = "/error", method = RequestMethod.GET)
		public ModelAndView err1() {
			return new ModelAndView("error", "book", new Book());
		}
		
		@RequestMapping(value = "/error", method = RequestMethod.POST)
		public ModelAndView err2() {
			return new ModelAndView("error", "book", new Book());
		}

}
