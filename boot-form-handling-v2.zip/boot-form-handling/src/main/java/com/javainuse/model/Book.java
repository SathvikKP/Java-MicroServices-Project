package com.javainuse.model;

public class Book {

	private String bookId;
	private String bookCategory;
	private String bookName;
	private String bookAuthor;
	private int bookEdition;
	private double bookPrice;
	
	//book-id
	public String getBookId() {
		return bookId;
	}

	public void setBookId(String bookId) {
		this.bookId = bookId;
	}
	
	//book-category
	public String getBookCategory() {
		return bookCategory;
	}
	
	public void setBookCategory(String bookCategory) {
		this.bookCategory=bookCategory;
	}
	
	//book-name
	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	
	//book-author
	public String getBookAuthor() {
		return bookAuthor;
	}

	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}
	
	//book-edition
	public int getBookEdition() {
		return bookEdition;
	}

	public void setBookEdition(int bookEdition) {
		this.bookEdition = bookEdition;
	}

	//book-price
	public double getBookPrice() {
		return bookPrice;
	}

	public void setBookPrice(double bookPrice) {
		this.bookPrice = bookPrice;
	}
	@Override
	public String toString() {
		return "Id: " + bookId +"\t Category: " + bookCategory+"\t Name: " + bookName +"\t Author: " + bookAuthor+"\t Edition: " + bookEdition+"\t Price: " + bookPrice ;
	}

}